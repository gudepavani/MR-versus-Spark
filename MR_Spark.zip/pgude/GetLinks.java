package com.pavanig.MRPageRank;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class GetLinks extends Configured implements Tool {
	
	 public static void main( String[] args) throws  Exception {
	      int resource  = ToolRunner .run( new GetLinks(), args);
	      System .exit(resource);
	   }

	public int run(String[] args) throws Exception {	
		
		Job job = Job.getInstance(getConf(), "GetLinks");	//fetching title : text from input file	
		job.setJarByClass(this.getClass());
		System.out.println(args[0]);
		System.out.println(args[1]+0);
		FileInputFormat.addInputPaths(job, args[0]);
		FileOutputFormat.setOutputPath(job, new Path(args[1]+0));		
		job.setMapperClass(Map .class);
	    job.setReducerClass(Reduce .class);
	    job.setOutputKeyClass( Text .class);
	    job.setOutputValueClass( Text .class);

	    if(job.waitForCompletion( true))
  	  	  return 0;
	    else return 1;
  				
	}
	
	 public static class Map extends Mapper<LongWritable,Text,Text,Text> {		 
		
		 @Override
		 public void map(LongWritable offset,  Text lineText,  Context context)
				 throws  IOException,  InterruptedException {
			 
	        String line  = lineText.toString();
	        Text url  = new Text();          
	        
	     	Matcher title_Key =  Pattern .compile(".*<title>(.*?)</title>.*").matcher(line); 
	     	
	    	if(title_Key.matches()){
	    		url  = new Text(title_Key.group(1).toString());
	    	
	    	
	    		Matcher outLinks = Pattern .compile("\\[\\[(.*?)\\]\\]").matcher(line);
	    		
	    		List<String> eachLink = new ArrayList<String>();
	    		
	    		while(outLinks.find()){
	    			String outlinks1 = outLinks.group();
	    			eachLink.add(outlinks1);
	    		}
	    		for(String word: eachLink)
    			{
    				if(word.isEmpty())
    				{
    					continue;
    				}
    				context.write(new Text(url),new Text(word));
    			}	
	    		
	    	}
	    		     	 
	}
		 
	 }
	 
	 public static class Reduce extends Reducer<Text ,  Text ,  Text ,  Text > {
		@Override
		public void reduce(Text url, Iterable<Text> outlinkslist,Context context)
				throws IOException, InterruptedException {
			
			double rank = 1.0;
			String outlink = rank+"#####"; 
			
			for ( Text outlinks  : outlinkslist) {
								
					outlink += outlinks.toString()+"@@@@@";
				
	         }		
			
			context.write(new Text(url), new Text(outlink));   //url an dpage rank to output file
			}	
		
	 }
}