package com.pavanig.MRPageRank;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class IntermediateStep  extends Configured implements Tool {
	
	public static void main( String[] args) throws  Exception {	      
		  int resource  = ToolRunner .run( new IntermediateStep(), args);
	      System .exit(resource);
	   }

	public int run(String[] args) throws Exception {
	
		Path interPath = new Path(args[1]);
	    Configuration config = getConf();
	    config.set("Path", interPath.toString());
		  
		Job job = Job.getInstance(getConf(), "IntermediateStep");		
		job.setJarByClass(this.getClass());	
		System.out.println(args[1]+Integer.toString(10));
		System.out.println(args[1]);	
		FileInputFormat.addInputPaths(job, args[1]+Integer.toString(10));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setMapperClass(Map .class);
	    job.setReducerClass(Reduce .class);
	    job.setMapOutputKeyClass(DoubleWritable.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass( Text .class);
	    job.setOutputValueClass( DoubleWritable.class);
	    job.setNumReduceTasks(1);
	    job.setSortComparatorClass(LongWritable.DecreasingComparator.class);
	    
	    if(job.waitForCompletion( true))
  	  	  return 0;
	    else return 1;	
	}
	
	 public static class Map extends Mapper<LongWritable,Text,DoubleWritable,Text> {		 
		 
	     @Override
		 public void map(LongWritable offset,  Text lineText,  Context context)
				 throws  IOException,  InterruptedException {
	         String line  = lineText.toString();
	         String url="";
	     	 
	         String[] input = line.split("\t");
			 url = input[0];
			 String[] rank_Outlinks = input[1].split("#####");	 
			 double PR = Double.parseDouble(rank_Outlinks[0].toString());
			 
			 
			 
	         context.write(new DoubleWritable(PR),new Text(url));  //getting url and page rank
	}
		 
	 }
	 public static class Reduce extends Reducer<DoubleWritable ,  Text ,  Text ,  DoubleWritable > {
			int i =0;
			 @Override	 
		public void reduce(DoubleWritable pageRank, Iterable<Text> urls,Context context)
				throws IOException, InterruptedException {
			
			 //getting all intermediate paths 
			String path = context.getConfiguration().get("Path");
			FileSystem fs = FileSystem.get(context.getConfiguration());
			
			int count =0;
			//removing all intermediate files 
			while(count <=10)
			{
				
				fs.delete(new Path(path+Integer.toString(count)),true);
				
				count++;
			}
			
			//writing first 100 lines of data to output file
			if(i<=100){
			
				for ( Text url  : urls) {		
					
					//System.out.println(url.toString()+"#"+pageRank);
					context.write(url, pageRank);
					i++;
		         }
				
				
				
			}	
			}
			
		
	 }
	 

}