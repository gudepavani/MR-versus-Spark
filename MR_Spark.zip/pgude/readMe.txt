Pavani Gude : 800923558

Project Assignment2
**********************
zip contains class files and also jar, readMe, pavani.py

Map reudce (MRPageRank)
  PageRank.java (entry point)	: conatins main job to calculate page rank based on the #outlinks
  IntermediateStep.java		: deletes all the unwanted intermediate files
  GetLinks.java			: fetches urls from the input


Input: wiki-micro.txt
output excerpt :  
links						pagerank

[[Special:DoubleRedirects|double-redirect]]	5.377500000000008
[[Wikipedia:GFDL standardization]]		3.8103124999999993
[[Wikipedia:Non-free content/templates]]	3.419464285714285
[[WP:AES|←]]					1.6375000000000006

Commands used:
hadoop fs -mkdir /user/<username>/input
hadoop fs -put <inputfile> /user/<username>/input
mkdir classFile
javac -cp /usr/lib/hadoop/*:/usr/lib/hadoop-mapreduce/* *.java -d classFile
jar -cvf MRPageRank.jar -C classFile/ .
hadoop jar MRPageRank.jar com.pavanig.MRPageRank /user/<username>/input /user/<username>/output
hadoop fs -getmerge /user/<username>/output mroutput


Map reduce- Spark
executed using Python.

pyspark pavani.py /user/<username>/input /user/<username>/output1
hadoop fs -getmerge /user/<username>/output1 sparkoutput

Differences experinced between Apache Spark and Hadoop -MR
  Spark was easier to program in a single class.
  Performance is be affected when inouts are of larger sizes (spark is faster) 
  Spark uses internal memory whereas MR in Hadoop generates large intermediate files and code has to be written explicitly to delete them.
