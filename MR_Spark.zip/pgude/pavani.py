from pyspark import SparkContext
import re
import sys
from operator import add
con=SparkContext()
con
input = con.textFile(sys.argv[1])

def parseNeighbours(urls):
	
	source=re.search('<title>(.*)</title>', urls).group(1)
	text=re.search('<text xml:(.*)</text>', urls).group(1)
	matches=re.findall(r'\[\[(.*)\]\]', text)
	segments=[]
	if len(matches)==0:
		return source, "NILL"
	else:
		for m in matches:
			segments.append(m)		
		for item in segments:
			return source, item

def contributionCalc(urls, rank):
	for data in urls:
		#getting urls into items which begin with [[ in the xml
		items=urls.split("[[")
	count = len(items)
	for url in items:
		return (url, rank / count)

# encoding input 
links=input.map(lambda x: x.encode('utf-8'))
links1 = links.map(lambda urls: parseNeighbours(urls))

corresRanks = links1.map(lambda url_neighbours: (url_neighbours[0], (1.0)))

for iteration in range(0, 10):
	contributions = links1.join(corresRanks).map(lambda x_rank: contributionCalc(x_rank[1][0], x_rank[1][1]))
	ranks = contributions.reduceByKey(add).mapValues(lambda rank: (rank * 0.85 + 0.15))
	# 0.85 damping factor , 1-d = 0.15

sortedOutput = ranks.sortBy(lambda a: a[1], False)
sortedOutput.saveAsTextFile(sys.argv[2])














