package com.pavanig.MRPageRank;

import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class PageRank extends Configured implements Tool {
	
	public static int num_iterations =0;
	public String strValIterations = Integer.toString(num_iterations + 1);
	
	 public static void main( String[] args) throws  Exception {
		
		int urls = ToolRunner.run(new GetLinks(), args);		
		int resource = 0;		
		
		for(int i = 0;i<10;i++){			//repeating the loop for 10 times to get the page rank
			resource  = ToolRunner .run( new PageRank(), args);
			num_iterations++;
		}
		
		int toCleanIntermediateFiles  = ToolRunner.run( new IntermediateStep(), args);    		
		System .exit(toCleanIntermediateFiles);
		
	}

	public int run(String[] args) throws Exception {
		
		Job job = Job.getInstance(getConf(), "PageRank");	// this job calculates page rank	
		job.setJarByClass(this.getClass());
		System.out.println(num_iterations);
		
		if(num_iterations==0){
			FileInputFormat.addInputPaths(job, args[1]+0);
		}
		else{
			FileInputFormat.addInputPaths(job, args[1]+Integer.toString(num_iterations));
		}
		
		FileOutputFormat.setOutputPath(job, new Path(args[1]+ strValIterations));	
		System.out.println(args[1]+Integer.toString(num_iterations));
		System.out.println(args[1]+Integer.toString(num_iterations+1));
		job.setMapperClass(Map .class);
	    job.setReducerClass(Reduce .class);	    
	    job.setOutputKeyClass( Text .class);
	    job.setOutputValueClass( Text .class);
	 // key value pair is logged with the separators
	    if(job.waitForCompletion( true))
	    	  	  return 0;
	    else return 1;
	    			
	}
	
	 public static class Map extends Mapper<LongWritable,Text,Text,Text> {		 // fetching page rank
		
		 @Override
		 public void map(LongWritable offset,  Text lineText,  Context context)
				 throws  IOException,  InterruptedException {
	    	
			 
			 String line  = lineText.toString().trim();			 
			 String url="", outlinksList ="";			 
			 double PR1;
			
			 String[] input = line.split("\t");
			 url = input[0];
			
			 String[] rank_Outlinks = input[1].split("#####");    // rank and outlinks
			 double PR = Double.parseDouble(rank_Outlinks[0].toString());
			 
			 if(rank_Outlinks.length>1)
			 {
				outlinksList = rank_Outlinks[1].toString();
					
				String[] outlinks = outlinksList.split("@@@@@");
				PR1 = PR/outlinks.length;
				
				for(String eachLink: outlinks)
				{
					context.write(new Text(eachLink),new Text(Double.toString(PR1)+""));
				}
			 }
			
			 context.write(new Text(url),new Text("@@"+outlinksList));	// key value pair is logged with the separators
			 
			}
	 }
	 
	 public static class Reduce extends Reducer<Text ,  Text ,  Text ,  Text > {
		@Override
		public void reduce(Text url, Iterable<Text> outlinkList,Context context)
				throws IOException, InterruptedException {
			
			String outlinksList ="";
			
			double Pr = 0.0;
			double d = 0.85;		//damping factor
			
			for ( Text link  : outlinkList)
			{  
				
					if(link.toString().startsWith("@@")){		//takes the output from mapper's context write
				
						outlinksList =  link.toString().substring(2).trim();
					}
					else if (!link.toString().equals(""))
					{
						Pr += Double.parseDouble(link.toString());
					}	
					
			}
			
			double Pr1 = (1-d) + ( d * Pr );  //0.15 + 0.85 * Pr
			
			context.write(new Text(url),new Text(Pr1+"#####"+outlinksList));					
		}	
	 }
}